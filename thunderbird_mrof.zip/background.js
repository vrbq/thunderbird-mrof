// background.js – OPTIMISED v2.2 (2025‑07‑31)
// -----------------------------------------------------------------------------
//  ✅  What’s new (user request 2025‑07‑31):
//  1. Verbose logging everywhere the folder detection pipeline runs.
//  2. When a thread has ≥ 3 unique Message‑IDs, chances are high a folder exists; if
//     the lookup comes back “not found”, we still enable the button and label it
//     “not found — search again”. A click triggers a fresh lookup bypassing the
//     cache so the user can force a retry.
//  3. Same retry path automatically triggered once just after display if the
//     first lookup returned not found while threadCount ≥ 3 (optimistic retry).
// -----------------------------------------------------------------------------

// -----------------------------------------------------------------------------
// 🔍 DEBUG switch & helpers
// -----------------------------------------------------------------------------
const DEBUG = true;
const debugLog = (...args) => DEBUG && console.log('[MROF]', ...args);
const benchmark = async (label, asyncFn) => {
  const t0 = performance.now();
  const res = await asyncFn();
  debugLog(`${label} took ${(performance.now() - t0).toFixed(2)} ms`);
  return res;
};

// -----------------------------------------------------------------------------
// 🔧  Utility helpers
// -----------------------------------------------------------------------------
const yieldToEventLoop = () => new Promise((r) => setTimeout(r, 0));
const rqIdle = (cb) =>
  typeof requestIdleCallback === 'function'
    ? requestIdleCallback(cb, { timeout: 1000 })
    : setTimeout(cb, 16);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// -----------------------------------------------------------------------------
// 🗂️ In‑memory LRU cache   threadKey → MailFolder | 'not found'   (session)
// -----------------------------------------------------------------------------
const MAX_CACHE_SIZE = 500;
/** @type {Map<string, import('webextension-api').MailFolder | 'not found'>} */
const folderCache = new Map();
const setCache = (key, val) => {
  if (folderCache.has(key)) folderCache.delete(key);
  folderCache.set(key, val);
  if (folderCache.size > MAX_CACHE_SIZE)
    folderCache.delete(folderCache.keys().next().value);
};

// -----------------------------------------------------------------------------
// 🏷️ Helpers & constants
// -----------------------------------------------------------------------------
const EXCLUDED_SPECIAL_USE = new Set([
  'inbox',
  'junk',
  'drafts',
  'sent',
]);
const isSystemFolder = (folder) =>
  (folder.specialUse || []).some((id) =>
    EXCLUDED_SPECIAL_USE.has(id)
  );
const MSG_ID_RE = /<[^>]+>/g;
const makeThreadKey = (ids) => ids.slice().sort().join(','); // stable key

// -----------------------------------------------------------------------------
// 📂 Folder pre‑filtering (skip system folders)
// -----------------------------------------------------------------------------
let cachedValidFolders = null; // Promise<MailFolder[]>
const getValidFolders = async () => {
  if (cachedValidFolders) return cachedValidFolders;
  cachedValidFolders = browser.folders
    .query({})
    .then((folders) => folders.filter((f) => !isSystemFolder(f)));
  return cachedValidFolders;
};

// -----------------------------------------------------------------------------
// ⛓️ Concurrency control
// -----------------------------------------------------------------------------
class Semaphore {
  constructor(max) {
    this.max = max;
    this.active = 0;
    this.queue = [];
  }
  async acquire() {
    if (this.active < this.max) {
      this.active++;
      return;
    }
    await new Promise((res) => this.queue.push(res));
    this.active++;
  }
  release() {
    this.active--;
    if (this.queue.length) this.queue.shift()();
  }
}
const sem = new Semaphore(6);
const withSemaphore = async (fn) => {
  await sem.acquire();
  try {
    return await fn();
  } finally {
    sem.release();
  }
};

// -----------------------------------------------------------------------------
// 📑 MessageList helpers (pagination)
// -----------------------------------------------------------------------------
const findInMessageList = async (list, predicate) => {
  let current = list;
  let match = current.messages.find(predicate);
  while (!match && current.id) {
    current = await browser.messages.continueList(current.id);
    match = current.messages.find(predicate);
  }
  return match || null;
};

// -----------------------------------------------------------------------------
// 🔄 Deduplication of ongoing folder lookups per headerMessageId
// -----------------------------------------------------------------------------
/** @type {Map<string, Promise<{folder: import('webextension-api').MailFolder, message: import('webextension-api').MessageHeader}>>} */
const ongoingIdLookups = new Map();
const LOOKUP_TIMEOUT_MS = 5000;

const lookupFolderForMsgId = (id) => {
  if (ongoingIdLookups.has(id)) return ongoingIdLookups.get(id);

  const p = (async () => {
    debugLog(' → lookupFolderForMsgId start', id);
    const result = await Promise.race([
      withSemaphore(async () => {
        const folders = await getValidFolders();
        for (const folder of folders) {
          const list = await browser.messages.query({
            folderId: folder.id,
            headerMessageId: id,
          });
          const hit = await findInMessageList(list, () => true);
          if (hit) {
            debugLog('   ↳ found in', folder.path);
            return { folder, message: hit };
          }
        }
        throw new Error('no‑valid‑folder');
      }),
      sleep(LOOKUP_TIMEOUT_MS).then(() => {
        throw new Error('timeout');
      }),
    ]);
    return result;
  })().finally(() => {
    debugLog(' ← lookupFolderForMsgId end', id);
    ongoingIdLookups.delete(id);
  });

  ongoingIdLookups.set(id, p);
  return p;
};

// -----------------------------------------------------------------------------
// 🌟 findFirstValidFolder(ids) – returns {folder, message}
// -----------------------------------------------------------------------------
async function findFirstValidFolder(uniqueIds) {
  debugLog('findFirstValidFolder() start', { ids: uniqueIds });
  return benchmark('findFirstValidFolder total', async () => {
    for (const id of uniqueIds) {
      try {
        const res = await lookupFolderForMsgId(id);
        if (res && res.folder) return res; // stop at first success
      } catch (e) {
        // continue to next id
        debugLog('  ↳ id failed, next', { id, error: e.message });
      }
    }
    debugLog('findFirstValidFolder → nothing found');
    return { folder: null, message: null };
  });
}

// -----------------------------------------------------------------------------
// 🧪 Subject-based suggestion (settings + runtime)
// -----------------------------------------------------------------------------
const MROF_SETTINGS_KEY = 'mrof_settings_v1';
const DEFAULT_SETTINGS = {
  subjectSuggestEnabled: true,
  subjectRegexList: [], // array of regex strings (e.g. "\\[insal-tc-stages4TC")
  subjectHintMap: {}, // pattern -> { id, path, ts }
};

// ephemeral per-session cache: threadKey -> { id, path }
const subjectSuggestionCache = new Map();

async function getSettings() {
  const obj = await browser.storage.local.get(MROF_SETTINGS_KEY);
  return { ...DEFAULT_SETTINGS, ...(obj[MROF_SETTINGS_KEY] || {}) };
}
async function saveSettings(next) {
  const merged = { ...(await getSettings()), ...next };
  await browser.storage.local.set({ [MROF_SETTINGS_KEY]: merged });
  return merged;
}

function safeRegexTest(pattern, text) {
  try {
    return new RegExp(pattern, 'i').test(text || '');
  } catch {
    return false;
  }
}

// Heuristic: if subject contains "[token...]", pick the token (including '[') until ']' or space; else take the first 40 chars.
function deriveMotifFromSubject(subject) {
  subject = subject || '';
  const m = subject.match(/\[[^\]\s]+/);
  if (m) return m[0]; // e.g. "[insal-tc-stages4TC"
  return subject.trim().slice(0, 40);
}

// Learn mapping pattern -> folder (id+path) after a successful move
async function learnSubjectMapping(subject, folder) {
  const settings = await getSettings();
  const hits = (settings.subjectRegexList || []).filter((p) =>
    safeRegexTest(p, subject)
  );
  if (!hits.length || !folder) return;
  for (const p of hits) {
    settings.subjectHintMap[p] = {
      id: folder.id,
      path: folder.path,
      ts: Date.now(),
    };
  }
  await saveSettings({ subjectHintMap: settings.subjectHintMap });
}

// Suggest a folder if detection failed: updates UI and caches suggestion; returns true if a suggestion was shown
async function maybeSuggestBySubject(
  tabId,
  threadCount,
  threadKey,
  msgHeader
) {
  try {
    const settings = await getSettings();
    if (!settings.subjectSuggestEnabled) return false;
    // Already suggested? re-apply UI
    if (subjectSuggestionCache.has(threadKey)) {
      const f = subjectSuggestionCache.get(threadKey);
      await browser.messageDisplayAction.enable(tabId);
      await setActionTitle(
        tabId,
        threadCount,
        `new, maybe ${f.path} ?`
      );
      return true;
    }
    // Read subject
    let subject = msgHeader?.subject || '';
    try {
      const full = await browser.messages.getFull(msgHeader.id);
      subject = full?.headers?.subject?.[0] || subject || '';
    } catch (_) {}
    const patterns = settings.subjectRegexList || [];
    for (const p of patterns) {
      if (!safeRegexTest(p, subject)) continue;
      const hint = settings.subjectHintMap?.[p];
      if (hint && hint.id && hint.path) {
        subjectSuggestionCache.set(threadKey, {
          id: hint.id,
          path: hint.path,
        });
        await browser.messageDisplayAction.enable(tabId);
        await setActionTitle(
          tabId,
          threadCount,
          `new, maybe ${hint.path} ?`
        );
        return true;
      }
    }
    return false;
  } catch (e) {
    // fail silently
    return false;
  }
}
// -----------------------------------------------------------------------------
// 🏃‍♂️ Core UI helpers
// -----------------------------------------------------------------------------
const setActionTitle = (tabId, threadCount, label) =>
  browser.messageDisplayAction.setTitle({
    title: `Thread (${threadCount}): ${label}`,
  });

const maybeEnableRetryUI = (tabId, threadCount, found) => {
  if (threadCount >= 3 && !found) {
    // Enable button so user can force a retry
    browser.messageDisplayAction.enable(tabId);
    setActionTitle(tabId, threadCount, 'not found — search again');
  }
};

// -----------------------------------------------------------------------------
// 🏃‍♂️ Core processing pipeline
// -----------------------------------------------------------------------------
async function processDisplayedMessage(tab, msgHeader) {
  const t0 = performance.now();
  try {
    await browser.messageDisplayAction.disable(tab.id);
    await setActionTitle(tab.id, 0, 'Loading…');

    // Extract IDs (unique + sorted)
    const { headers } = await browser.messages.getFull(msgHeader.id);
    const raw = `${headers.references?.[0] || ''}${
      headers['In-Reply-To']?.[0] || ''
    }${headers['Message-ID']?.[0] || ''}`;
    const ids = Array.from(
      new Set(raw.match(MSG_ID_RE)?.map((s) => s.slice(1, -1)) || [])
    );
    // Try most-recent first: References are chronological; Message-ID is current
    ids.reverse();
    const threadKey = makeThreadKey(ids);
    const threadCount = ids.length;

    debugLog('processDisplayedMessage', { threadKey, threadCount });

    const cached = folderCache.get(threadKey);
    if (cached) {
      const label =
        cached === 'not found' ? 'not found' : cached.path;
      await setActionTitle(tab.id, threadCount, label);
      if (cached !== 'not found') {
        await browser.messageDisplayAction.enable(tab.id);
      } else {
        maybeEnableRetryUI(tab.id, threadCount, false);
        // 🧠 Subject-based suggestion from cache miss (still not found)
        await maybeSuggestBySubject(
          tab.id,
          threadCount,
          threadKey,
          msgHeader
        );
      }
      debugLog('  ↳ cache hit, done');
      return;
    }

    await new Promise((res) => rqIdle(res));
    debugLog('  ↳ cache miss → lookup');

    const { folder } = await findFirstValidFolder(ids);
    setCache(threadKey, folder || 'not found');

    if (folder) {
      await setActionTitle(tab.id, threadCount, folder.path);
      await browser.messageDisplayAction.enable(tab.id);
    } else {
      debugLog('  ↳ first lookup not found');
      await setActionTitle(tab.id, threadCount, 'not found');
      // 🧠 Subject-based suggestion (only when not found)
      await maybeSuggestBySubject(
        tab.id,
        threadCount,
        threadKey,
        msgHeader
      );

      maybeEnableRetryUI(tab.id, threadCount, false);

      // 🔁 automatic optimistic retry (once)
      if (threadCount >= 3) {
        await yieldToEventLoop();
        debugLog('  ↳ optimistic retry');
        const retry = await findFirstValidFolder(ids);
        if (retry.folder) {
          setCache(threadKey, retry.folder);
          await setActionTitle(
            tab.id,
            threadCount,
            retry.folder.path
          );
          await browser.messageDisplayAction.enable(tab.id);
        }
      }
    }

    debugLog('processDisplayedMessage done', {
      elapsed: (performance.now() - t0).toFixed(2),
    });
  } catch (err) {
    debugLog('Error in processDisplayedMessage', err);
  }
}

// -----------------------------------------------------------------------------
// 1️⃣ Listener: message displayed
// -----------------------------------------------------------------------------
browser.messageDisplay.onMessageDisplayed.addListener(
  (tab, msgHeader) => {
    rqIdle(() => processDisplayedMessage(tab, msgHeader));
  }
);

// -----------------------------------------------------------------------------
// 2️⃣ Listener: toolbar button click
// -----------------------------------------------------------------------------
browser.messageDisplayAction.onClicked.addListener(async (tab) => {
  const startTime = performance.now();
  debugLog('onClicked()', { tabId: tab.id });

  try {
    const displayed =
      await browser.messageDisplay.getDisplayedMessage(tab.id);
    const { headers } = await browser.messages.getFull(displayed.id);
    const raw = `${headers.references?.[0] || ''}${
      headers['In-Reply-To']?.[0] || ''
    }${headers['Message-ID']?.[0] || ''}`;
    const ids = Array.from(
      new Set(raw.match(MSG_ID_RE)?.map((s) => s.slice(1, -1)) || [])
    );
    // Try most-recent first: References are chronological; Message-ID is current
    ids.reverse();
    const threadKey = makeThreadKey(ids);

    // 👉 If a subject-based suggestion exists for this thread, use it directly
    if (subjectSuggestionCache.has(threadKey)) {
      const suggested = subjectSuggestionCache.get(threadKey);
      targetFolder = { id: suggested.id, path: suggested.path };
      debugLog('onClicked(): using subject suggestion', suggested);
    }
    const threadCount = ids.length;

    debugLog('onClicked thread', { threadKey, threadCount });

    let cached = folderCache.get(threadKey);
    let targetFolder = null;
    let destinationMsg = null;

    // Force a fresh lookup if we had "not found" but threadCount ≥ 3
    const mustForce = cached === 'not found' && threadCount >= 3;

    if (!cached || mustForce) {
      debugLog('  ↳ performing (re)lookup');
      const result = await findFirstValidFolder(ids);
      targetFolder = result.folder;
      destinationMsg = result.message;
      setCache(threadKey, targetFolder || 'not found');
    } else if (cached !== 'not found') {
      targetFolder = cached;
      debugLog('  ↳ cache hit (folder)', targetFolder.path);
      // find a message in that folder by headerMessageId (robust)
      for (const mid of ids) {
        const list = await browser.messages.query({
          folderId: targetFolder.id,
          headerMessageId: mid,
        });
        destinationMsg = await findInMessageList(list, () => true);
        if (destinationMsg) break;
      }
    }

    if (!destinationMsg) throw new Error('No valid folder found');

    await browser.messages.move([displayed.id], targetFolder.id);
    // Learn mapping for subject-based suggestion
    try {
      const full = await browser.messages.getFull(displayed.id);
      await learnSubjectMapping(
        full?.headers?.subject?.[0] || displayed.subject || '',
        targetFolder
      );
    } catch (_) {}
    // Clear any suggestion for this thread
    try {
      subjectSuggestionCache.delete(threadKey);
    } catch (_) {}
    await browser.notifications.create({
      type: 'basic',
      iconUrl: browser.runtime.getURL('icons/clippy-256.ico'),
      title: 'Message moved',
      message: `Moved to: ${targetFolder.path}`,
    });
  } catch (err) {
    debugLog('onClicked() error', err);
    await browser.notifications.create({
      type: 'basic',
      iconUrl: browser.runtime.getURL('icons/clippy-256.ico'),
      title: 'Error',
      message: err.message,
    });
  } finally {
    debugLog('onClicked() end', {
      elapsed: (performance.now() - startTime).toFixed(2),
    });
  }
});

// -----------------------------------------------------------------------------
// 🧰 MROF – Right‑click menu on the toolbar button: “Relancer la recherche”
//    Bypasses the cache for the current thread and re‑runs folder detection.
// -----------------------------------------------------------------------------
(async function initMrofContextMenu() {
  try {
    await browser.menus.removeAll();
  } catch (e) {
    /* ignore */
  }

  // Create the single menu entry on the message_display_action button.
  browser.menus.create({
    id: 'mrof-force-refresh',
    title: 'Relancer la recherche (ignorer le cache)',
    contexts: ['message_display_action'],
  });

  // Settings parent menu
  browser.menus.create({
    id: 'mrof-settings',
    title: 'Paramètres',
    contexts: ['message_display_action'],
  });
  browser.menus.create({
    id: 'mrof-param-toggle',
    title: 'Activer la suggestion par sujet',
    contexts: ['message_display_action'],
    parentId: 'mrof-settings',
  });
  browser.menus.create({
    id: 'mrof-param-add-from-subject',
    title: 'Ajouter motif (depuis le sujet affiché)',
    contexts: ['message_display_action'],
    parentId: 'mrof-settings',
  });
  browser.menus.create({
    id: 'mrof-param-clear',
    title: 'Effacer tous les motifs',
    contexts: ['message_display_action'],
    parentId: 'mrof-settings',
  });

  browser.menus.onShown.addListener(async (info, tab) => {
    try {
      const s = await getSettings();
      await browser.menus.update('mrof-param-toggle', {
        title: s.subjectSuggestEnabled
          ? 'Désactiver la suggestion par sujet'
          : 'Activer la suggestion par sujet',
      });
      await browser.menus.refresh();
    } catch (_) {}
  });

  browser.menus.onClicked.addListener(async (info, tab) => {
    if (info.menuItemId === 'mrof-param-toggle') {
      const s = await getSettings();
      await saveSettings({
        subjectSuggestEnabled: !s.subjectSuggestEnabled,
      });
      try {
        await browser.notifications.create({
          type: 'basic',
          iconUrl: browser.runtime.getURL('icons/clippy-256.ico'),
          title: 'MROF',
          message: s.subjectSuggestEnabled
            ? 'Suggestion par sujet désactivée'
            : 'Suggestion par sujet activée',
        });
      } catch (_) {}
      return;
    }
    if (info.menuItemId === 'mrof-param-add-from-subject') {
      try {
        const displayed =
          await browser.messageDisplay.getDisplayedMessage(tab.id);
        const full = await browser.messages.getFull(displayed.id);
        const subj =
          full?.headers?.subject?.[0] || displayed.subject || '';
        const motif = deriveMotifFromSubject(subj);
        const s = await getSettings();
        const list = new Set(s.subjectRegexList || []);
        // Treat motif as literal by escaping regexp specials
        const escaped = motif.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        list.add(escaped);
        await saveSettings({ subjectRegexList: Array.from(list) });
        await browser.notifications.create({
          type: 'basic',
          iconUrl: browser.runtime.getURL('icons/clippy-256.ico'),
          title: 'MROF',
          message: `Motif ajouté: ${motif}`,
        });
      } catch (e) {
        await browser.notifications.create({
          type: 'basic',
          iconUrl: browser.runtime.getURL('icons/clippy-256.ico'),
          title: 'MROF',
          message: `Impossible d'ajouter un motif: ${e.message}`,
        });
      }
      return;
    }
    if (info.menuItemId === 'mrof-param-clear') {
      await saveSettings({
        subjectRegexList: [],
        subjectHintMap: {},
      });
      try {
        await browser.notifications.create({
          type: 'basic',
          iconUrl: browser.runtime.getURL('icons/clippy-256.ico'),
          title: 'MROF',
          message: 'Motifs effacés.',
        });
      } catch (_) {}
      return;
    }
    if (info.menuItemId !== 'mrof-force-refresh') return;
    try {
      const displayed =
        await browser.messageDisplay.getDisplayedMessage(tab.id);
      if (!displayed) throw new Error('Aucun message affiché');

      // Recompute the thread key from headers.
      const { headers } = await browser.messages.getFull(
        displayed.id
      );
      const raw = `${headers.references?.[0] || ''}${
        headers['In-Reply-To']?.[0] || ''
      }${headers['Message-ID']?.[0] || ''}`;
      const ids = Array.from(
        new Set(
          raw.match(MSG_ID_RE)?.map((s) => s.slice(1, -1)) || []
        )
      );
      ids.reverse(); // recent first, as elsewhere in the code
      const threadKey = makeThreadKey(ids);

      // Bust caches for this thread.
      try {
        if (folderCache && typeof folderCache.delete === 'function')
          folderCache.delete(threadKey);
      } catch (_) {}
      try {
        if (typeof ongoingIdLookups?.clear === 'function')
          ongoingIdLookups.clear();
      } catch (_) {}

      // Update UI and trigger a fresh lookup using existing pipeline.
      await browser.messageDisplayAction.disable(tab.id);
      await setActionTitle(tab.id, ids.length, 'recherche…');
      await processDisplayedMessage(tab, displayed);

      // Small toast to confirm the manual refresh was triggered.
      try {
        await browser.notifications.create({
          type: 'basic',
          iconUrl: browser.runtime.getURL('icons/clippy-256.ico'),
          title: 'MROF',
          message: 'Recherche relancée (cache ignoré).',
        });
      } catch (_) {}
    } catch (e) {
      try {
        await browser.notifications.create({
          type: 'basic',
          iconUrl: browser.runtime.getURL('icons/clippy-256.ico'),
          title: 'MROF',
          message: `Échec de la relance : ${e.message}`,
        });
      } catch (_) {}
    }
  });
})();
